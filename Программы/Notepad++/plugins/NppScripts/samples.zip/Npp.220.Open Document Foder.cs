//npp_toolbar_image Shell32.dll|3
using System;
using NppScripts;

public class Script : NppScript
{
    public override void Run()
    {
        string path;
        Win32.SendMessage(Npp.NppHandle, NppMsg.NPPM_GETFULLCURRENTPATH, 0, out path);
        System.Diagnostics.Process.Start("explorer.exe", "/select," + path);
    }
}