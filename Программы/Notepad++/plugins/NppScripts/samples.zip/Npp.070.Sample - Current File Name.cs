using System;
using NppScripts;

public class Script : NppScript
{
    public override void Run()
    {
        string path;
        Win32.SendMessage(Npp.NppHandle, NppMsg.NPPM_GETFILENAME, 0, out path);
        Win32.SendMessage(Npp.CurrentScintilla, SciMsg.SCI_REPLACESEL, 0, path);
    }
}
