using System.Text;
using System;
using System.Drawing;
using System.Threading;

namespace NppScripts.Automation
{
    public class Editor
    {
        static public void MenuFileNew()
        {
            Win32.SendMessage(Npp.NppHandle, NppMsg.NPPM_MENUCOMMAND, 0, NppMenuCmd.IDM_FILE_NEW);
        }

        static public int GetCaretPos()
        {
            return (int)Win32.SendMessage(Npp.CurrentScintilla, SciMsg.SCI_GETCURRENTPOS, 0, 0);
        }

        static public int SetCaretPos(int pos)
        {
            return (int)Win32.SendMessage(Npp.CurrentScintilla, SciMsg.SCI_SETCURRENTPOS, pos, pos);
        }

        static public void SetSelection(int start, int length = 0)
        {
            Win32.SendMessage(Npp.CurrentScintilla, SciMsg.SCI_SETSELECTION, start, start+length);
        }

        static public string GetSelectedText()
        {
            int start = (int)Win32.SendMessage(Npp.CurrentScintilla, SciMsg.SCI_GETSELECTIONSTART, 0, 0);
            int end = (int)Win32.SendMessage(Npp.CurrentScintilla, SciMsg.SCI_GETSELECTIONEND, 0, 0);
            var text = new StringBuilder(end - start + 1);
            Win32.SendMessage(Npp.CurrentScintilla, SciMsg.SCI_GETSELTEXT, 0, text);
            return text.ToString();
        }

        static public void GrabFocus()
        {
            Win32.SendMessage(Npp.CurrentScintilla, SciMsg.SCI_GRABFOCUS, 0, 0);
        }

        static public int SelectWorAtCaret()
        {
            Point p;
            Npp.GetWordAtCursor(out p);
            Win32.SendMessage(Npp.CurrentScintilla, SciMsg.SCI_SETSELECTION, p.X, p.Y);
            return p.Y;
        }

        static public void ReplaceSelection(string text)
        {
            Win32.SendMessage(Npp.CurrentScintilla, SciMsg.SCI_REPLACESEL, 0, text);
        }

        static public void TypeText(string text, int delay = 20)
        {
            int currentPos = GetCaretPos();

            Win32.SendMessage(Npp.CurrentScintilla, SciMsg.SCI_SETSELECTION, currentPos, currentPos);

            foreach (char c in text)
            {
                Thread.Sleep(delay);
                ReplaceSelection(c.ToString());
                SetCaretPos(++currentPos);
            }
        }

        static public void SetText(string text)
        {
            Npp.SetAllText(text);
        }

        static public string GetText()
        {
            return Npp.GetAllText();
        }

        static public string GetTextBetween(int start, int end = -1)
        {
            IntPtr sci = Plugin.GetCurrentScintilla();

            if (end == -1)
                end = (int)Win32.SendMessage(sci, SciMsg.SCI_GETLENGTH, 0, 0);

            using (var tr = new Sci_TextRange(start, end, end - start + 1)) //+1 for null termination
            {
                Win32.SendMessage(sci, SciMsg.SCI_GETTEXTRANGE, 0, tr.NativePointer);
                return tr.lpstrText;
            }
        }
    }
}