using System;
using System.Linq;
using NppScripts;

public class Script : NppScript
{
    public override void Run()
    {
        string path;
        Win32.SendMessage(Npp.NppHandle, NppMsg.NPPM_GETFULLCURRENTPATH, 0, out path);
        
        ClearOutput();
        WriteLine("Current file is {0}", path);
        WriteLine("Current time is " + DateTime.Now);
        Npp.Output.WriteLine("Test"); //default Automation output panel
    }

    void WriteLine(string text, params object[] args)
    {
        Plugin.GetOutputPanel()
              .Call("OpenOrCreateOutput", "Automation")
              .Call("WriteLine", text, args);
    }
    
    void ClearOutput()
    {
        Plugin.GetOutputPanel()
              .Call("OpenOrCreateOutput", "Automation")
              .Call("Clear");
    }
}