//css_inc automation.cs
using System.Diagnostics;
using System.Threading.Tasks;
using System.Threading;
using System;
using System.Windows.Forms;
using NppScripts;
using NppScripts.Automation;

public class Script : NppScript
{
    public override void Run()
    {
        Editor.MenuFileNew();
        Editor.GrabFocus();

        Task.Factory.StartNew(() =>
        {
            Editor.TypeText("Hello, Notepad++... from .NET!");

            Blink(6, 7, 9, '.');
            SelectWordsAt(0, 9, 23, 29);
            SplitCharacters();
            ReportCompletion();
        });
    }

    void ReportCompletion()
    {
        Editor.SetSelection(0);
        Editor.ReplaceSelection("\r\n");
        Editor.ReplaceSelection("\r\n");
        Editor.SetSelection(0);
        Editor.TypeText("---------- ALL DONE ----------");
        Blink(8, 11, 8);
        Editor.SetSelection(0);
        Thread.Sleep(500);
    }

    void SplitCharacters()
    {
        string text = Npp.GetAllText();
        int pos = text.Length-1;

        while (pos > 0)
        {
            Thread.Sleep(50);
            Editor.SetSelection(pos);
            Editor.ReplaceSelection("\r\n");
            pos--;
        }

        pos = 1;
        while(pos < text.Length)
        {
            Thread.Sleep(50);
            Editor.SetSelection(pos, 2);
            Editor.ReplaceSelection("");
            pos++;
        }

        Editor.SetSelection(0);
        Thread.Sleep(500);
    }

    void SelectWordsAt(params int[] positions)
    {
        foreach(int pos in positions)
        {
            Thread.Sleep(700);
            Editor.SetSelection(pos);
            Editor.SelectWorAtCaret();
        }

        Thread.Sleep(500);
    }

    void Blink(int count, int start, int length, char substitutionCharBase = ' ')
    {
        string original = Editor.GetTextBetween(start, start+length);
        string hidden = new string(substitutionCharBase, length);
        for(int i = 0; i < count; i++)
        {
            Thread.Sleep(500);

            string replacement = (i % 2) == 0 ? hidden : original;

            Editor.SetSelection(start, length);
            Editor.ReplaceSelection(replacement);
            Editor.SetSelection(0, 0);
        }
    }
}