using System.Text;
using System;
using System.Windows.Forms;
using NppScripts;

/*
 '//npp_toolbar_image Shell32.dll|3' associates the script with the 16x16 icon #3 from Shell32.dll and places it on the toolbar
 '//npp_shortcut Ctrl+Alt+Shift+F12' associates the script with the shortcut Ctrl+Alt+Shift+F12
*/

public class Script : NppScript
{
    public override void Run()
    {
        string buf;
        
        //Win32.SendMessage(Npp.NppHandle, NppMsg.NPPM_GETFULLCURRENTPATH, 0, out buf);
        //var sci = Npp.CurrentScintilla;
        // Win32.SendMessage(Npp.CurrentScintilla, SciMsg.SCI_GETLINE, 16, 0);
        //IntPtr line = Win32.SendMessage(Npp.CurrentScintilla, SciMsg.SCI_GETCURLINE, 0, out buf);
        //IntPtr line = Win32.SendMessage(Npp.CurrentScintilla, SciMsg.SCI_GETLINE, 16, out buf);
        
        int line = GetLineNumber(GetCaretPosition());
        WriteLine(line);
        WriteLine(GetLine(line));
        
        int startPos = GetCaretPosition();
        int endPos = startPos + 4;
        Win32.SendMessage(Npp.CurrentScintilla, SciMsg.SCI_SETTARGETSTART, startPos, 0);
        Win32.SendMessage(Npp.CurrentScintilla, SciMsg.SCI_SETTARGETEND, endPos, 0);
        Win32.SendMessage(Npp.CurrentScintilla, SciMsg.SCI_REPLACETARGET, 4, "test");
        
        //SCI_SETTARGETSTART()
        
        // int caretPolicy; int caretSlop;
        // //Win32.SendMessage(sci, SciMsg.SCI_SETVISIBLEPOLICY, caretPolicy,  caretSlop);
        // //Win32.SendMessage(sci, SciMsg.SCI_SETENDATLASTLINE, 2,  0);
        // Win32.SendMessage(sci, SciMsg.SCI_SCROLLCARET, 0,  0);
        // Win32.SendMessage(sci, SciMsg.SCI_LINESCROLL, 0,  2);
        // Win32.SendMessage(sci, SciMsg.SCI_SCROLLCARET, 0,  0);
        // Win32.SendMessage(sci, SciMsg.SCI_GRABFOCUS, 0,  0);
        //int currentPos = (int)Win32.SendMessage(sci, SciMsg.SCI_GETCURRENTPOS, 0, 0);
        //int line = (int)Win32.SendMessage(sci, SciMsg.SCI_LINEFROMPOSITION, currentPos, 0);
        // IntPtr result = Win32.SendMessage(Npp.CurrentScintilla, SciMsg.SCI_GETCURLINE, 0, 0)+1;
        //IntPtr result = Win32.SendMessage(Npp.CurrentScintilla, SciMsg.SCI_GETLINEVISIBLE, 0, 0)+1;
        //var result = Win32.SendMessage(Npp.CurrentScintilla, SciMsg.SCI_GETFIRSTVISIBLELINE, 0, 0)+1;
        //var line = Win32.SendMessage(Npp.CurrentScintilla, SciMsg.SCI_GETENDATLASTLINE, 0, 0);
        //var line = GetFirstVisibleLine();
        //MessageBox.Show(line.ToString());
    }

    int GetCaretPosition()
    {
        IntPtr sci = Npp.CurrentScintilla;
        int currentPos = (int)Win32.SendMessage(sci, SciMsg.SCI_GETCURRENTPOS, 0, 0);
        return currentPos;
    }

    string GetLine(int line)
    {
        IntPtr sci = Npp.CurrentScintilla;
            
        int length = (int)Win32.SendMessage(sci, SciMsg.SCI_LINELENGTH, line, 0);
        var buffer = new StringBuilder(length + 1);
        Win32.SendMessage(sci, SciMsg.SCI_GETLINE, line, buffer);
        buffer.Length = length;        //NPP may inject some rubbish at the end of the line
        return buffer.ToString();
    }

    int GetLineNumber(int position)
    {
        IntPtr sci = Npp.CurrentScintilla;
        return (int)Win32.SendMessage(sci, SciMsg.SCI_LINEFROMPOSITION, position, 0);
    }

    int GetLineCount()
    {
        IntPtr sci = Npp.CurrentScintilla;
        return (int)Win32.SendMessage(sci, SciMsg.SCI_GETLINECOUNT, 0, 0);
    }

    void WriteLine(object text, params object[] args)
    {
        var msg = string.Format((text??"").ToString(), args);
        var output = Plugin.GetOutputPanel().Call("OpenOrCreateOutput", "Automation");
        output.Call("WriteLine", msg, new string[0]);
    }

    void ClearOutput()
    {
        Plugin.GetOutputPanel()
              .Call("OpenOrCreateOutput", "Automation")
              .Call("Clear");
    }

    int GetFirstVisibleLine()
    {
        return (int)Win32.SendMessage(Npp.CurrentScintilla, SciMsg.SCI_GETLINEVISIBLE, 0, 0);
    }

    int GetCaretLine()
    {
        var sci = Npp.CurrentScintilla;
        int currentPos = (int)Win32.SendMessage(sci, SciMsg.SCI_GETCURRENTPOS, 0, 0);
        return (int)Win32.SendMessage(sci, SciMsg.SCI_LINEFROMPOSITION, currentPos, 0);
    }
}