//npp_shortcut Ctrl+Shift+F11
using System.Text;
using System;
using System.Windows.Forms;
using NppScripts;

public class Script : NppScript
{
    public override void Run()
    {
        string text = Npp.GetAllText();
        Npp.SetAllText(FormatCSharp(text));
    }

    string FormatCSharp(string text)
    {
        var buffer = new StringBuilder();

        bool prevLineIsEmpty = false;

        foreach(string line in text.Split(new []{ Environment.NewLine }, System.StringSplitOptions.None))
        {
            bool isEmpty = string.IsNullOrWhiteSpace(line);

            if(isEmpty)
            {
                if(!prevLineIsEmpty)
                    buffer.AppendLine("");
            }
            else
                buffer.AppendLine(line);

            prevLineIsEmpty = isEmpty;
        }
        return buffer.ToString();
    }
}

