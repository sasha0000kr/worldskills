//npp_shortcut Ctrl+F11
using System;
using System.IO;
using System.Linq;
using System.Xml;
using NppScripts;

public class Script : NppScript
{
    public override void Run()
    {
        try
        {
            string text = Npp.GetAllText();
            Npp.SetAllText(FormatXML(text));
        }
        catch(Exception e)
        {
            Npp.Output.Clear();
            Npp.Output.WriteLine("'Format XML Document' Error:\r\n"+e.Message);
        }
    }

    string FormatXML(string data)
    {
        var xmlDocument = new XmlDocument();
        xmlDocument.LoadXml(data);

        using(var stringWriter = new StringWriter())
        using (var xmlWriter = new XmlTextWriter(stringWriter) { Formatting = Formatting.Indented, Indentation = 4 })
        {
            xmlDocument.WriteTo(xmlWriter);
            return stringWriter.ToString();
        }
    }
}